@echo off
echo ========================================================
echo   PyPong Analytics - Starting FastAPI Backend Server
echo ========================================================
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    set "PYTHON_EXE=.venv\Scripts\python.exe"
) else (
    set "PYTHON_EXE=python"
)

echo Using Python: %PYTHON_EXE%
echo Starting Uvicorn at http://127.0.0.1:8000 ...
"%PYTHON_EXE%" -m uvicorn backend.app:app --reload --host 127.0.0.1 --port 8000
pause
