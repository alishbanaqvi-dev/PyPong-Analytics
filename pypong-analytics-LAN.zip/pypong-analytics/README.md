# PyPong Analytics

A full-stack desktop arcade game and real-time telemetry analytics platform built with Python, Pygame, FastAPI, SQLite, Docker, and GitHub Actions CI.

---

## 📁 Project Architecture & Directory Structure

```text
pypong-analytics/
├── .github/
│   └── workflows/
│       └── ci.yml             # GitHub Actions CI workflow (linting & testing)
├── backend/
│   ├── app.py                 # FastAPI backend server with SQLite telemetry logging
│   ├── Dockerfile             # Container definition for the FastAPI backend
│   ├── requirements.txt       # Backend dependencies (fastapi, uvicorn, pydantic, etc.)
│   ├── test_app.py            # Unit & integration tests for all API endpoints
│   └── templates/
│       └── dashboard.html     # Real-time web analytics command center UI
├── frontend/
│   ├── game.py                # Pygame desktop client with real-time AI & HTTP telemetry
│   └── requirements.txt       # Frontend dependencies (pygame, requests)
├── .gitignore                 # Git ignore rules for Python, SQLite, Docker
├── docker-compose.yml         # Container orchestration with volume persistence
├── run_all.bat                # 1-click launcher for backend and frontend
├── run_backend.bat            # 1-click launcher for FastAPI backend
├── run_game.bat               # 1-click launcher for Pygame client
├── run_tests.bat              # 1-click script for Flake8 linting & Pytest suite
└── README.md                  # Comprehensive setup and usage documentation
```

---

## ⚡ Quick Start (Windows 1-Click Launchers)

For convenience, ready-to-run batch files are provided in the project root:

- **Launch Full Stack (Backend + Game)**: Double-click `run_all.bat`
- **Launch Backend Only**: Double-click `run_backend.bat`
- **Launch Game Only**: Double-click `run_game.bat` (or run `run_game.bat "MyPlayerName"`)
- **Run Linters & Test Suite**: Double-click `run_tests.bat`

---

## 🚀 Manual Setup & Execution

### 1. Prerequisites
- **Python 3.10+** (Python 3.11 recommended)
- **Docker & Docker Compose** (optional for containerized deployment)

---

### 2. Back-End Setup (FastAPI & SQLite)

1. Navigate to the `backend/` directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the development server:
   ```bash
   uvicorn app:app --reload --host 127.0.0.1 --port 8000
   ```

4. Available Endpoints:
   - **Live Web Analytics Command Center**: [http://127.0.0.1:8000/](http://127.0.0.1:8000/)
   - **Interactive API Docs (Swagger UI)**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
   - **Health Check Endpoint**: [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health)
   - **Leaderboard Endpoint**: [http://127.0.0.1:8000/api/v1/leaderboard](http://127.0.0.1:8000/api/v1/leaderboard)
   - **Aggregated Stats Endpoint**: [http://127.0.0.1:8000/api/v1/stats](http://127.0.0.1:8000/api/v1/stats)
   - **Recent Match Stream**: [http://127.0.0.1:8000/api/v1/matches](http://127.0.0.1:8000/api/v1/matches)

5. Run backend tests:
   ```bash
   pytest test_app.py
   ```

6. Run code linter:
   ```bash
   flake8 app.py test_app.py --max-line-length=120
   ```

---

### 3. Front-End Setup (Pygame Desktop Client)

1. Navigate to the `frontend/` directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Launch the game:
   ```bash
   python game.py "Student_Player"
   ```

#### Game Controls:
- **W** or **Up Arrow**: Move paddle up
- **S** or **Down Arrow**: Move paddle down
- **R**: Restart match after game over
- First to reach **5 points** wins!
- Upon match conclusion, telemetry metrics (`player_name`, `player_score`, `opponent_score`, `game_duration_sec`) are automatically transmitted to the FastAPI backend at `http://127.0.0.1:8000/api/v1/scores`.

---

### 4. Running with Docker Compose

To run the containerized backend with persistent SQLite storage:

```bash
docker-compose up --build
```

The API will be exposed on port `8000`. The SQLite database is persisted in `./backend/data/pypong_analytics.db` on your host machine.

---

### 5. CI/CD Pipeline

The repository includes a GitHub Actions workflow located in `.github/workflows/ci.yml`. On every push or pull request to the `main` branch, the workflow:
1. Checks out the code.
2. Sets up Python 3.10.
3. Installs backend dependencies.
4. Lints `backend/app.py` and `backend/test_app.py` with `flake8`.
5. Verifies backend module imports and executes the complete `pytest` test suite.


## LAN Multiplayer (new)

PyPong now includes a two-device LAN mode. One device hosts the match and the
second device joins it over the same local network (Wi-Fi or Ethernet).

### How to play

1. Connect both computers to the same Wi-Fi network or router.
2. On the host computer, run `run_game.bat` (or start the game normally).
3. In the game menu, press **N** for **LAN Multiplayer**, then choose **1**
   to host. The host waits for the other player to connect.
4. On the second computer, start the game, press **N**, then choose **2** to
   join. Enter the host computer's local IPv4 address.
5. On Windows, find the host IPv4 address by opening Command Prompt and running
   `ipconfig`. Use the IPv4 Address under the active Wi-Fi/Ethernet adapter.
6. Allow Python through Windows Firewall on **Private networks** if Windows
   asks. Both devices use TCP port **5050**.

### Controls in LAN mode

- Host (left paddle): **W** to move up, **S** to move down.
- Joining player (right paddle): **Up Arrow** to move up, **Down Arrow** to move down.
- Press **Esc** to leave the match.

The host computer runs the game simulation and sends the ball, score, and paddle
positions to the joining computer. This keeps both screens synchronized. LAN
mode is separate from the existing single-player, local two-player,
four-player, tournament, shop, achievements, save data, and analytics features.

**Important:** LAN mode works on the same local network. It does not provide
internet matchmaking or remote play across different networks.
