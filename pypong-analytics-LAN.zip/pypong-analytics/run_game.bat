@echo off
echo ========================================================
echo   PyPong Analytics - Starting Pygame Desktop Client
echo ========================================================
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    set "PYTHON_EXE=.venv\Scripts\python.exe"
) else (
    set "PYTHON_EXE=python"
)

echo Using Python: %PYTHON_EXE%
"%PYTHON_EXE%" frontend\game.py %*
pause
