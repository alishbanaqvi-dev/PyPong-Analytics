from fastapi.testclient import TestClient
from app import app as fastapi_app

client = TestClient(fastapi_app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "pypong-backend"


def test_log_match_score_success():
    payload = {
        "player_name": "Test_Player",
        "player_score": 5,
        "opponent_score": 3,
        "game_duration_sec": 42.5
    }
    response = client.post("/api/v1/scores", json=payload)
    assert response.status_code == 201
    assert response.json() == {
        "status": "SUCCESS",
        "message": "Match telemetry logged successfully"
    }


def test_log_match_score_invalid_payload():
    # Negative score should fail pydantic validation
    payload = {
        "player_name": "Test_Player",
        "player_score": -1,
        "opponent_score": 3,
        "game_duration_sec": 42.5
    }
    response = client.post("/api/v1/scores", json=payload)
    assert response.status_code == 422


def test_get_leaderboard():
    response = client.get("/api/v1/leaderboard?limit=5")
    assert response.status_code == 200
    data = response.json()
    assert "leaderboard" in data
    assert isinstance(data["leaderboard"], list)


def test_get_stats():
    response = client.get("/api/v1/stats")
    assert response.status_code == 200
    data = response.json()
    assert "total_matches" in data
    assert "win_rate_percent" in data
    assert "avg_duration_sec" in data


def test_get_matches():
    response = client.get("/api/v1/matches?limit=5")
    assert response.status_code == 200
    data = response.json()
    assert "matches" in data
    assert isinstance(data["matches"], list)


def test_dashboard_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert "PyPong Analytics" in response.text
