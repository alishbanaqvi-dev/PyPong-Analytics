import os
import sqlite3
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

app = FastAPI(title="PyPong Analytics API", version="1.0.0")

# Database Path Configuration (supports Docker volume persistence via DB_DIR or DB_FILE)
DB_DIR = os.getenv("DB_DIR", ".")
if DB_DIR and DB_DIR != "." and not os.path.exists(DB_DIR):
    os.makedirs(DB_DIR, exist_ok=True)

DB_FILE = os.getenv("DB_FILE", os.path.join(DB_DIR, "pypong_analytics.db"))

TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "templates", "dashboard.html")


# --- Database Setup ---
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS match_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_name TEXT NOT NULL,
            player_score INTEGER NOT NULL,
            opponent_score INTEGER NOT NULL,
            game_duration_sec REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


init_db()


# --- Pydantic Data Schemas ---
class MatchResult(BaseModel):
    player_name: str = Field(..., min_length=1, max_length=50)
    player_score: int = Field(..., ge=0)
    opponent_score: int = Field(..., ge=0)
    game_duration_sec: float = Field(..., gt=0.0)


# --- REST Endpoints ---
@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "pypong-backend"}


@app.post("/api/v1/scores", status_code=201)
def log_match_score(data: MatchResult):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO match_logs (player_name, player_score, opponent_score, game_duration_sec)
            VALUES (?, ?, ?, ?)
        """, (data.player_name, data.player_score, data.opponent_score, data.game_duration_sec))
        conn.commit()
        conn.close()
        return {"status": "SUCCESS", "message": "Match telemetry logged successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database insertion failed: {str(e)}")


@app.get("/api/v1/leaderboard")
def get_leaderboard(limit: int = 10):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT player_name, player_score, opponent_score, timestamp
        FROM match_logs
        ORDER BY player_score DESC, game_duration_sec ASC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()

    leaderboard = [
        {"player_name": row[0], "player_score": row[1], "opponent_score": row[2], "date": row[3]}
        for row in rows
    ]
    return {"leaderboard": leaderboard}


@app.get("/api/v1/stats")
def get_overall_stats():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT
            COUNT(*) as total_matches,
            SUM(CASE WHEN player_score > opponent_score THEN 1 ELSE 0 END) as total_wins,
            AVG(game_duration_sec) as avg_duration,
            MAX(player_score) as max_player_score,
            SUM(player_score) as total_points_scored
        FROM match_logs
    """)
    row = cursor.fetchone()
    conn.close()

    total_matches = row[0] or 0
    total_wins = row[1] or 0
    avg_duration = round(row[2], 2) if row[2] else 0.0
    max_score = row[3] or 0
    total_points = row[4] or 0
    win_rate = round((total_wins / total_matches) * 100, 1) if total_matches > 0 else 0.0

    return {
        "total_matches": total_matches,
        "total_wins": total_wins,
        "total_losses": total_matches - total_wins,
        "win_rate_percent": win_rate,
        "avg_duration_sec": avg_duration,
        "max_player_score": max_score,
        "total_points_scored": total_points
    }


@app.get("/api/v1/matches")
def get_recent_matches(limit: int = Query(20, ge=1, le=100)):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, player_name, player_score, opponent_score, game_duration_sec, timestamp
        FROM match_logs
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()

    matches = [
        {
            "id": row[0],
            "player_name": row[1],
            "player_score": row[2],
            "opponent_score": row[3],
            "game_duration_sec": row[4],
            "timestamp": row[5],
            "result": "WIN" if row[2] > row[3] else ("LOSS" if row[2] < row[3] else "DRAW")
        }
        for row in rows
    ]
    return {"matches": matches}


@app.get("/", response_class=HTMLResponse)
def analytics_dashboard():
    if os.path.exists(TEMPLATE_PATH):
        with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>PyPong Analytics API is Running.</h1><p>Visit /docs for API schema.</p>"


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
