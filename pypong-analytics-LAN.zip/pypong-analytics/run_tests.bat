@echo off
echo ========================================================
echo   PyPong Analytics - Running Linter and Test Suite
echo ========================================================
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    set "VENV_BIN=.venv\Scripts\"
) else (
    set "VENV_BIN="
)

echo [1/3] Linting backend code with Flake8...
"%VENV_BIN%flake8" backend/app.py backend/test_app.py --max-line-length=120
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Backend linting failed!
    exit /b %ERRORLEVEL%
)
echo [OK] Backend linting passed!

echo [2/3] Linting frontend code with Flake8...
"%VENV_BIN%flake8" frontend/game.py --max-line-length=120
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Frontend linting failed!
    exit /b %ERRORLEVEL%
)
echo [OK] Frontend linting passed!

echo [3/3] Running Pytest test suite...
"%VENV_BIN%pytest" backend/test_app.py -v
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Pytest tests failed!
    exit /b %ERRORLEVEL%
)
echo ========================================================
echo   ALL QUALITY CHECKS PASSED SUCCESSFULLY!
echo ========================================================
pause
