@echo off
echo ========================================================
echo   PyPong Analytics - Starting Full Stack Application
echo ========================================================
cd /d "%~dp0"

echo [1/2] Starting Backend API in separate window...
start "PyPong Backend API" cmd /k run_backend.bat

echo Waiting 2 seconds for API to initialize...
timeout /t 2 /nobreak >nul

echo [2/2] Launching Pygame Client...
call run_game.bat
