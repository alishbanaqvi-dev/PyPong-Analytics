import sys
import time
import requests
import pygame
import json
import os
import socket
import threading

# --- Display & Physics Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PADDLE_WIDTH = 24       
PADDLE_HEIGHT = 90      
BALL_SIZE = 15
MAX_BALL_SPEED = 18

# Racquet Proportions
BLADE_HEIGHT = 65       
HANDLE_WIDTH = 8        
HANDLE_HEIGHT = 25      

# Color Palette
COLOR_WHITE = (255, 255, 255)
COLOR_GREEN = (46, 204, 113)
COLOR_RED = (231, 76, 60)
COLOR_WOOD = (184, 115, 51)
COLOR_YELLOW = (241, 196, 15)
COLOR_GRAY = (200, 200, 200)
COLOR_TRAIL = (100, 200, 255)

# Unlockable Assets
THEMES = {
    "Classic Navy": {"bg": (27, 54, 93), "lines": COLOR_WHITE, "cost": 0},
    "Cyberpunk": {"bg": (15, 15, 25), "lines": (255, 0, 255), "cost": 100},
    "Grass Court": {"bg": (34, 139, 34), "lines": (255, 255, 255), "cost": 100}
}

PADDLES = {
    "Standard": {"color": COLOR_GREEN, "cost": 0},
    "Neon Blue": {"color": (0, 255, 255), "cost": 50},
    "Golden": {"color": (255, 215, 0), "cost": 150}
}

API_URL = "http://127.0.0.1:8000/api/v1/scores"
SAVE_FILE = "save_data.json"


class LanConnection:
    """Small TCP helper: one host and one joining player on the same Wi-Fi/LAN."""
    def __init__(self, sock, is_host=False):
        self.sock = sock
        self.is_host = is_host
        self.latest = {}
        self.lock = threading.Lock()
        self.send_lock = threading.Lock()
        self.running = True
        self.buffer = b""
        threading.Thread(target=self._reader, daemon=True).start()

    @classmethod
    def host(cls, port=5050):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", port))
        server.listen(1)
        print(f"\nLAN game waiting on port {port}.")
        print("Give the other player this computer's local IPv4 address.")
        print("On Windows run: ipconfig  (look for IPv4 Address)")
        print("Waiting for player to join...")
        conn, address = server.accept()
        server.close()
        print("Player connected:", address)
        return cls(conn, True)

    @classmethod
    def join(cls, host_ip, port=5050):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(15)
        sock.connect((host_ip, port))
        sock.settimeout(None)
        return cls(sock, False)

    def _reader(self):
        try:
            while self.running:
                chunk = self.sock.recv(4096)
                if not chunk:
                    break
                self.buffer += chunk
                while b"\n" in self.buffer:
                    line, self.buffer = self.buffer.split(b"\n", 1)
                    if line:
                        try:
                            message = json.loads(line.decode("utf-8"))
                            with self.lock:
                                self.latest = message
                        except (ValueError, UnicodeDecodeError):
                            pass
        except OSError:
            pass
        finally:
            self.running = False

    def send(self, message):
        if not self.running:
            return
        try:
            raw = (json.dumps(message) + "\n").encode("utf-8")
            with self.send_lock:
                self.sock.sendall(raw)
        except OSError:
            self.running = False

    def get_latest(self):
        with self.lock:
            return dict(self.latest)

    def close(self):
        self.running = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


class PyPongGame:
    def __init__(self, player_name: str = "Player 1", winning_score: int = 11):
        pygame.init()
        self.is_fullscreen = False
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("PING PONG")
        self.clock = pygame.time.Clock()
        
        self.title_font = pygame.font.SysFont("Calibri", 56, bold=True)
        self.score_font = pygame.font.SysFont("Calibri", 36, bold=True)
        self.menu_font = pygame.font.SysFont("Calibri", 24, bold=True)
        self.font = pygame.font.SysFont("Calibri", 20, bold=True)
        
        self.player_name = player_name
        self.winning_score = winning_score
        
        self.game_state = "MENU"
        self.game_mode = 1
        
        self.tournament_active = False
        self.tournament_stage = 0
        self.tournament_stages = ["Quarter-Final", "Semi-Final", "Grand Final"]
        self.ai_difficulty_levels = [5.5, 8.5, 15.0] 
        
        self.paddles = []
        self.ball_trail = []
        self.left_score = 0
        self.right_score = 0
        self.match_reward_given = False
        self.lan = None
        self.lan_role = None
        self.lan_status = ""
        self.remote_controls = {}

        self.load_progress()


    def start_lan_game(self):
        print("\n=== LAN MULTIPLAYER ===")
        print("1. Host a game")
        print("2. Join a game")
        choice = input("Choose (1/2): ").strip()
        try:
            if choice == "1":
                print("\nYou are the HOST.")
                print("Start this option first, then join from the second device.")
                self.lan = LanConnection.host()
                self.lan_role = "host"
            elif choice == "2":
                host_ip = input("Enter HOST computer's IPv4 address: ").strip()
                self.lan = LanConnection.join(host_ip)
                self.lan_role = "client"
                print("Connected to host!")
            else:
                print("Invalid choice.")
                return
            self.init_match(2, False)
            self.lan_status = "HOST" if self.lan_role == "host" else "CONNECTED"
        except (OSError, ValueError) as error:
            print("Could not start LAN game:", error)
            print("Check that both devices are on the same Wi-Fi/LAN and the host IP is correct.")
            if self.lan:
                self.lan.close()
            self.lan = None
            self.lan_role = None

    def send_lan_state(self):
        if not self.lan or self.lan_role != "host":
            return
        message = {
            "type": "state",
            "ball": [self.ball.x, self.ball.y],
            "ball_speed": [self.ball_speed_x, self.ball_speed_y],
            "scores": [self.left_score, self.right_score],
            "paddles": [[p["rect"].x, p["rect"].y] for p in self.paddles],
            "game_state": self.game_state,
            "connected": self.lan.running
        }
        self.lan.send(message)

    def receive_lan_state(self):
        if not self.lan:
            return
        message = self.lan.get_latest()
        if not message:
            return
        if message.get("type") == "controls" and self.lan_role == "host":
            self.remote_controls = message.get("keys", {})
        elif message.get("type") == "state" and self.lan_role == "client":
            if hasattr(self, "ball") and len(message.get("ball", [])) == 2:
                self.ball.x, self.ball.y = message["ball"]
                self.ball_speed_x, self.ball_speed_y = message.get("ball_speed", [5, 5])
                self.left_score, self.right_score = message.get("scores", [0, 0])
                for paddle, position in zip(self.paddles, message.get("paddles", [])):
                    paddle["rect"].x, paddle["rect"].y = position
                self.game_state = message.get("game_state", self.game_state)
                self.lan_status = "CONNECTED" if message.get("connected", True) else "DISCONNECTED"

    def send_lan_controls(self):
        if self.lan and self.lan_role == "client":
            keys = pygame.key.get_pressed()
            self.lan.send({
                "type": "controls",
                "keys": {
                    "up": bool(keys[pygame.K_UP] or keys[pygame.K_w]),
                    "down": bool(keys[pygame.K_DOWN] or keys[pygame.K_s])
                }
            })

    def toggle_fullscreen(self):
        self.is_fullscreen = not self.is_fullscreen
        if self.is_fullscreen:
            try:
                self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN | pygame.SCALED)
            except pygame.error:
                self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    def load_progress(self):
        default_data = {
            "points": 0,
            "wins": 0,
            "tournaments_won": 0,
            "equipped_theme": "Classic Navy",
            "equipped_paddle": "Standard",
            "unlocked_themes": ["Classic Navy"],
            "unlocked_paddles": ["Standard"],
            "achievements": []
        }
        if os.path.exists(SAVE_FILE):
            with open(SAVE_FILE, "r") as f:
                self.data = json.load(f)
                for key, val in default_data.items():
                    if key not in self.data:
                        self.data[key] = val
        else:
            self.data = default_data
            self.save_progress()

    def save_progress(self):
        with open(SAVE_FILE, "w") as f:
            json.dump(self.data, f, indent=4)

    def check_achievements(self):
        achieved = []
        if self.data["wins"] >= 1 and "First Win" not in self.data["achievements"]:
            self.data["achievements"].append("First Win")
            self.data["points"] += 20
            achieved.append("First Win (+20 pts)")
        if self.data["tournaments_won"] >= 1 and "Champion" not in self.data["achievements"]:
            self.data["achievements"].append("Champion")
            self.data["points"] += 100
            achieved.append("Champion (+100 pts)")
        if self.data["points"] >= 500 and "High Roller" not in self.data["achievements"]:
            self.data["achievements"].append("High Roller")
            achieved.append("High Roller Unlocked!")
        
        if achieved:
            self.save_progress()
            print(f"ACHIEVEMENT UNLOCKED: {', '.join(achieved)}")

    def init_match(self, mode: int, is_tournament: bool = False, custom_ai_speed: float = 5.5) -> None:
        self.game_mode = mode
        self.tournament_active = is_tournament
        if not is_tournament:
            self.tournament_stage = 0
            
        self.game_state = "PLAYING"
        self.left_score = 0
        self.right_score = 0
        self.start_time = time.time()
        self.telemetry_sent = False
        self.match_reward_given = False
        self.ball_trail.clear()
        
        self.ball = pygame.Rect(SCREEN_WIDTH // 2 - BALL_SIZE // 2, SCREEN_HEIGHT // 2 - BALL_SIZE // 2, BALL_SIZE, BALL_SIZE)
        self.ball_speed_x = 5
        self.ball_speed_y = 5
        self.paddle_speed = 7
        
        self.ai_speed = self.ai_difficulty_levels[self.tournament_stage] if is_tournament else custom_ai_speed
        
        p1_color = PADDLES[self.data["equipped_paddle"]]["color"]
        
        self.paddles = []
        if mode == 1: 
            self.paddles.append({"rect": pygame.Rect(20, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": p1_color, "type": "P1", "side": "left", "vy": 0})
            self.paddles.append({"rect": pygame.Rect(SCREEN_WIDTH - 20 - PADDLE_WIDTH, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": COLOR_RED, "type": "AI", "side": "right", "vy": 0})
        elif mode == 2:
            self.paddles.append({"rect": pygame.Rect(20, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": p1_color, "type": "P1", "side": "left", "vy": 0})
            self.paddles.append({"rect": pygame.Rect(SCREEN_WIDTH - 20 - PADDLE_WIDTH, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": COLOR_RED, "type": "P2", "side": "right", "vy": 0})
        elif mode == 4:
            self.paddles.append({"rect": pygame.Rect(20, SCREEN_HEIGHT // 4 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": p1_color, "type": "P1", "side": "left", "vy": 0})
            self.paddles.append({"rect": pygame.Rect(20, SCREEN_HEIGHT * 3 // 4 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": p1_color, "type": "P3", "side": "left", "vy": 0})
            self.paddles.append({"rect": pygame.Rect(SCREEN_WIDTH - 20 - PADDLE_WIDTH, SCREEN_HEIGHT // 4 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": COLOR_RED, "type": "P2", "side": "right", "vy": 0})
            self.paddles.append({"rect": pygame.Rect(SCREEN_WIDTH - 20 - PADDLE_WIDTH, SCREEN_HEIGHT * 3 // 4 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT), "color": COLOR_RED, "type": "P4", "side": "right", "vy": 0})

    def process_inputs(self) -> None:
        keys = pygame.key.get_pressed()
        center_buffer = 10
        for p in self.paddles:
            old_y = p["rect"].y
            if p["type"] == "P1":
                if keys[pygame.K_w] and p["rect"].top > 0: p["rect"].y -= self.paddle_speed
                if keys[pygame.K_s] and p["rect"].bottom < SCREEN_HEIGHT: p["rect"].y += self.paddle_speed
                if keys[pygame.K_a] and p["rect"].left > 0: p["rect"].x -= self.paddle_speed
                if keys[pygame.K_d] and p["rect"].right < (SCREEN_WIDTH // 2) - center_buffer: p["rect"].x += self.paddle_speed
            elif p["type"] == "P2":
                if self.lan and self.lan_role == "host":
                    if self.remote_controls.get("up") and p["rect"].top > 0:
                        p["rect"].y -= self.paddle_speed
                    if self.remote_controls.get("down") and p["rect"].bottom < SCREEN_HEIGHT:
                        p["rect"].y += self.paddle_speed
                else:
                    if keys[pygame.K_UP] and p["rect"].top > 0: p["rect"].y -= self.paddle_speed
                    if keys[pygame.K_DOWN] and p["rect"].bottom < SCREEN_HEIGHT: p["rect"].y += self.paddle_speed
                    if keys[pygame.K_LEFT] and p["rect"].left > (SCREEN_WIDTH // 2) + center_buffer: p["rect"].x -= self.paddle_speed
                    if keys[pygame.K_RIGHT] and p["rect"].right < SCREEN_WIDTH: p["rect"].x += self.paddle_speed
            elif p["type"] == "P3":
                if keys[pygame.K_t] and p["rect"].top > 0: p["rect"].y -= self.paddle_speed
                if keys[pygame.K_g] and p["rect"].bottom < SCREEN_HEIGHT: p["rect"].y += self.paddle_speed
                if keys[pygame.K_f] and p["rect"].left > 0: p["rect"].x -= self.paddle_speed
                if keys[pygame.K_h] and p["rect"].right < (SCREEN_WIDTH // 2) - center_buffer: p["rect"].x += self.paddle_speed
            elif p["type"] == "P4":
                if keys[pygame.K_i] and p["rect"].top > 0: p["rect"].y -= self.paddle_speed
                if keys[pygame.K_k] and p["rect"].bottom < SCREEN_HEIGHT: p["rect"].y += self.paddle_speed
                if keys[pygame.K_j] and p["rect"].left > (SCREEN_WIDTH // 2) + center_buffer: p["rect"].x -= self.paddle_speed
                if keys[pygame.K_l] and p["rect"].right < SCREEN_WIDTH: p["rect"].x += self.paddle_speed
            
            p["vy"] = p["rect"].y - old_y 

    def update_ai(self) -> None:
        for p in self.paddles:
            if p["type"] == "AI":
                old_y = p["rect"].y
                target_y = self.ball.centery

                if self.ai_speed > 6.0 and self.ball_speed_x > 0:
                    distance_x = p["rect"].centerx - self.ball.centerx
                    time_to_reach = distance_x / self.ball_speed_x
                    predicted_y = self.ball.centery + (self.ball_speed_y * time_to_reach)
                    
                    if predicted_y < 0:
                        predicted_y = abs(predicted_y)
                    elif predicted_y > SCREEN_HEIGHT:
                        predicted_y = SCREEN_HEIGHT - (predicted_y - SCREEN_HEIGHT)
                        
                    target_y = predicted_y

                buffer_zone = 8 if self.ai_speed < 10 else 2
                
                # Y-Axis movement
                if p["rect"].centery < target_y - buffer_zone and p["rect"].bottom < SCREEN_HEIGHT:
                    p["rect"].y += self.ai_speed
                elif p["rect"].centery > target_y + buffer_zone and p["rect"].top > 0:
                    p["rect"].y -= self.ai_speed
                
                # X-Axis movement
                default_x = SCREEN_WIDTH - 20 - PADDLE_WIDTH
                if self.ball.x > SCREEN_WIDTH // 2 and self.ball_speed_x > 0:
                    if p["rect"].centerx > self.ball.centerx + 10 and p["rect"].left > (SCREEN_WIDTH // 2) + 10:
                        p["rect"].x -= self.ai_speed
                else:
                    if p["rect"].x < default_x:
                        p["rect"].x += self.ai_speed
                        
                p["vy"] = p["rect"].y - old_y

    def update_physics(self) -> None:
        self.ball_trail.append(self.ball.center)
        if len(self.ball_trail) > 8:
            self.ball_trail.pop(0)

        self.ball.x += self.ball_speed_x
        self.ball.y += self.ball_speed_y

        if self.ball.top <= 0 or self.ball.bottom >= SCREEN_HEIGHT:
            self.ball_speed_y *= -1
            self.ball.y += self.ball_speed_y 

        for p in self.paddles:
            if self.ball.colliderect(p["rect"]):
                if p["side"] == "left" and self.ball_speed_x < 0:
                    self.ball_speed_x = min(abs(self.ball_speed_x) * 1.08, MAX_BALL_SPEED) 
                    self.ball_speed_y += p["vy"] * 0.35 
                    self.ball.left = p["rect"].right 
                elif p["side"] == "right" and self.ball_speed_x > 0:
                    self.ball_speed_x = -min(abs(self.ball_speed_x) * 1.08, MAX_BALL_SPEED) 
                    self.ball_speed_y += p["vy"] * 0.35 
                    self.ball.right = p["rect"].left

        if self.ball.left <= 0:
            self.right_score += 1
            self.reset_ball()
        elif self.ball.right >= SCREEN_WIDTH:
            self.left_score += 1
            self.reset_ball()

        if (self.left_score >= self.winning_score or self.right_score >= self.winning_score):
            self.handle_game_over()

    def handle_game_over(self):
        if not self.telemetry_sent:
            self.send_telemetry()
            self.telemetry_sent = True
            
        if self.tournament_active:
            if self.left_score > self.right_score:
                if not self.match_reward_given:
                    self.data["points"] += 15
                    self.data["wins"] += 1
                    self.match_reward_given = True
                self.tournament_stage += 1
                if self.tournament_stage >= len(self.tournament_stages):
                    self.game_state = "TOURNAMENT_OVER"
                    self.data["points"] += 50
                    self.data["tournaments_won"] += 1
                else:
                    self.game_state = "GAME_OVER" 
            else:
                self.game_state = "TOURNAMENT_OVER" 
        else:
            if self.left_score > self.right_score and not self.match_reward_given:
                self.data["points"] += 10
                self.data["wins"] += 1
                self.match_reward_given = True
            self.game_state = "GAME_OVER"
            
        self.save_progress()
        self.check_achievements()

    def reset_ball(self) -> None:
        self.ball.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.ball_speed_x = 5 if self.ball_speed_x < 0 else -5
        self.ball_speed_y = 5
        self.ball_trail.clear()
        
        for p in self.paddles:
            if p["side"] == "left":
                p["rect"].x = 20
            else:
                p["rect"].x = SCREEN_WIDTH - 20 - PADDLE_WIDTH

    def send_telemetry(self) -> None:
        duration = round(time.time() - self.start_time, 2)
        payload = {
            "player_name": self.player_name,
            "player_score": self.left_score,
            "opponent_score": self.right_score,
            "game_duration_sec": duration,
            "mode": self.game_mode,
            "tournament_stage": self.tournament_stage
        }
        try:
            requests.post(API_URL, json=payload, timeout=2.0)
        except requests.exceptions.RequestException:
            pass

    def draw_racquet(self, paddle_rect: pygame.Rect, rubber_color: tuple) -> None:
        handle_x = paddle_rect.centerx - (HANDLE_WIDTH // 2)
        handle_y = paddle_rect.top + BLADE_HEIGHT - 5
        handle_rect = pygame.Rect(handle_x, handle_y, HANDLE_WIDTH, HANDLE_HEIGHT)
        pygame.draw.rect(self.screen, COLOR_WOOD, handle_rect, border_radius=3)
        
        blade_rect = pygame.Rect(paddle_rect.x, paddle_rect.y, PADDLE_WIDTH, BLADE_HEIGHT)
        pygame.draw.ellipse(self.screen, rubber_color, blade_rect)

    def render_menu(self) -> None:
        self.screen.fill(THEMES[self.data["equipped_theme"]]["bg"])
        
        title = self.title_font.render("PING PONG", True, COLOR_WHITE)
        pts = self.font.render(f"Points: {self.data['points']}   |   Wins: {self.data['wins']}", True, COLOR_GRAY)
        
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 70))
        self.screen.blit(pts, (SCREEN_WIDTH // 2 - pts.get_width() // 2, 130))

        options = [
            ("1", "Single Player"),
            ("2", "Two Player"),
            ("4", "Four Player"),
            ("T", "Tournament"),
            ("N", "LAN Multiplayer"),
            ("S", "Shop & Stats"),
            ("F", "Toggle Fullscreen"),
            ("ESC", "Quit")
        ]

        start_y = 165
        padding_y = 48
        rect_w = 320
        rect_h = 42

        for i, (key, text) in enumerate(options):
            rect_x = SCREEN_WIDTH // 2 - rect_w // 2
            rect_y = start_y + i * padding_y
            
            pygame.draw.rect(self.screen, COLOR_GRAY, (rect_x, rect_y, rect_w, rect_h), width=2, border_radius=6)
            
            opt_surface = self.menu_font.render(f"[{key}]  {text}", True, COLOR_WHITE)
            text_x = rect_x + (rect_w - opt_surface.get_width()) // 2
            text_y = rect_y + (rect_h - opt_surface.get_height()) // 2
            self.screen.blit(opt_surface, (text_x, text_y))

    def render_shop(self) -> None:
        self.screen.fill((20, 20, 30))
        title = self.title_font.render(f"Shop & Unlocks - Points: {self.data['points']}", True, COLOR_YELLOW)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 30))
        
        y_offset = 120
        self.screen.blit(self.menu_font.render("Paddles (Press Q, W, E to Buy/Equip)", True, COLOR_WHITE), (50, y_offset))
        y_offset += 40
        keys = ['Q', 'W', 'E']
        for i, (name, details) in enumerate(PADDLES.items()):
            status = "[EQUIPPED]" if self.data["equipped_paddle"] == name else ("[UNLOCKED]" if name in self.data["unlocked_paddles"] else f"[{details['cost']} pts]")
            color = COLOR_GREEN if self.data["equipped_paddle"] == name else COLOR_GRAY
            txt = self.font.render(f"[{keys[i]}] {name} - {status}", True, color)
            self.screen.blit(txt, (70, y_offset))
            y_offset += 30
            
        y_offset += 40
        self.screen.blit(self.menu_font.render("Themes (Press A, S, D to Buy/Equip)", True, COLOR_WHITE), (50, y_offset))
        y_offset += 40
        keys2 = ['A', 'S', 'D']
        for i, (name, details) in enumerate(THEMES.items()):
            status = "[EQUIPPED]" if self.data["equipped_theme"] == name else ("[UNLOCKED]" if name in self.data["unlocked_themes"] else f"[{details['cost']} pts]")
            color = COLOR_GREEN if self.data["equipped_theme"] == name else COLOR_GRAY
            txt = self.font.render(f"[{keys2[i]}] {name} - {status}", True, color)
            self.screen.blit(txt, (70, y_offset))
            y_offset += 30

        y_offset += 40
        self.screen.blit(self.menu_font.render("Achievements", True, COLOR_YELLOW), (50, y_offset))
        y_offset += 40
        ach_txt = ", ".join(self.data["achievements"]) if self.data["achievements"] else "None yet..."
        self.screen.blit(self.font.render(ach_txt, True, COLOR_WHITE), (70, y_offset))

        back_txt = self.font.render("Press [ESC] to go Back", True, COLOR_GRAY)
        self.screen.blit(back_txt, (SCREEN_WIDTH // 2 - back_txt.get_width() // 2, 540))

    def handle_shop_purchase(self, item_type: str, item_name: str, item_dict: dict):
        unlocked_list = self.data[f"unlocked_{item_type}s"]
        if item_name in unlocked_list:
            self.data[f"equipped_{item_type}"] = item_name
        else:
            cost = item_dict[item_name]["cost"]
            if self.data["points"] >= cost:
                self.data["points"] -= cost
                unlocked_list.append(item_name)
                self.data[f"equipped_{item_type}"] = item_name
        self.save_progress()

    def render_difficulty_select(self) -> None:
        self.screen.fill(THEMES["Classic Navy"]["bg"])
        title = self.title_font.render("Select AI Difficulty", True, COLOR_YELLOW)
        opt1 = self.menu_font.render("Press [1] - Easy", True, COLOR_GREEN)
        opt2 = self.menu_font.render("Press [2] - Medium", True, COLOR_WHITE)
        opt3 = self.menu_font.render("Press [3] - Hard", True, COLOR_RED)
        back_txt = self.font.render("Press [ESC] to go Back", True, COLOR_GRAY)
        
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 100))
        self.screen.blit(opt1, (SCREEN_WIDTH // 2 - opt1.get_width() // 2, 250))
        self.screen.blit(opt2, (SCREEN_WIDTH // 2 - opt2.get_width() // 2, 320))
        self.screen.blit(opt3, (SCREEN_WIDTH // 2 - opt3.get_width() // 2, 390))
        self.screen.blit(back_txt, (SCREEN_WIDTH // 2 - back_txt.get_width() // 2, 500))

    def render_game(self) -> None:
        theme = THEMES[self.data["equipped_theme"]]
        self.screen.fill(theme["bg"])
        
        pygame.draw.rect(self.screen, theme["lines"], self.screen.get_rect(), width=8)
        
        for y in range(0, SCREEN_HEIGHT, 30):
            pygame.draw.line(self.screen, theme["lines"], (SCREEN_WIDTH // 2, y), (SCREEN_WIDTH // 2, y + 15))
            
        if self.tournament_active:
            stage_txt = self.font.render(f"Stage: {self.tournament_stages[self.tournament_stage]}", True, COLOR_YELLOW)
            self.screen.blit(stage_txt, (SCREEN_WIDTH - stage_txt.get_width() - 20, 20))
        
        for p in self.paddles:
            self.draw_racquet(p["rect"], p["color"])
            
        for i, pos in enumerate(self.ball_trail):
            radius = max(1, int(BALL_SIZE/2 * (i / len(self.ball_trail))))
            pygame.draw.circle(self.screen, COLOR_TRAIL, pos, radius)
            
        pygame.draw.ellipse(self.screen, COLOR_WHITE, self.ball)
        
        score_txt = f"{self.left_score}   -   {self.right_score}"
        score_surface = self.score_font.render(score_txt, True, theme["lines"])
        self.screen.blit(score_surface, (SCREEN_WIDTH // 2 - score_surface.get_width() // 2, 30))

        if self.game_state in ["GAME_OVER", "TOURNAMENT_OVER"]:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(180)
            overlay.fill((0, 0, 0))
            self.screen.blit(overlay, (0, 0))
            
            if self.tournament_active and self.game_state == "GAME_OVER":
                msg = f"{self.tournament_stages[self.tournament_stage-1]} Cleared! +15 Pts"
                color = COLOR_GREEN
                sub_msg_txt = "Press [ENTER] for Next Match or [ESC] for Menu"
            elif self.tournament_active and self.game_state == "TOURNAMENT_OVER":
                if self.left_score > self.right_score:
                    msg = "TOURNAMENT CHAMPION! +50 Pts"
                    color = COLOR_YELLOW
                else:
                    msg = "Eliminated."
                    color = COLOR_RED
                sub_msg_txt = "Press [ESC] for Menu"
            else:
                winner = "Left Team" if self.left_score > self.right_score else "Right Team"
                color = COLOR_GREEN if winner == "Left Team" else COLOR_RED
                pts_str = " (+10 Pts)" if winner == "Left Team" else ""
                msg = f"{winner} Wins!{pts_str}"
                sub_msg_txt = "Press [ESC] for Menu"

            end_msg = self.title_font.render(msg, True, color)
            sub_msg = self.font.render(sub_msg_txt, True, COLOR_WHITE)
            
            self.screen.blit(end_msg, (SCREEN_WIDTH // 2 - end_msg.get_width() // 2, SCREEN_HEIGHT // 2 - 40))
            self.screen.blit(sub_msg, (SCREEN_WIDTH // 2 - sub_msg.get_width() // 2, SCREEN_HEIGHT // 2 + 20))

    def run(self) -> None:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    if self.lan: self.lan.close()
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if self.game_state == "MENU":
                        if event.key == pygame.K_1: self.game_state = "DIFFICULTY_SELECT"
                        if event.key == pygame.K_2: self.init_match(2, False)
                        if event.key == pygame.K_4: self.init_match(4, False)
                        if event.key == pygame.K_t: self.init_match(1, True)
                        if event.key == pygame.K_n: self.start_lan_game()
                        if event.key == pygame.K_s: self.game_state = "SHOP"
                        if event.key == pygame.K_f: self.toggle_fullscreen()
                        if event.key == pygame.K_ESCAPE:
                            pygame.quit()
                            sys.exit()
                    elif self.game_state == "SHOP":
                        if event.key == pygame.K_ESCAPE: self.game_state = "MENU"
                        p_keys = {pygame.K_q: "Standard", pygame.K_w: "Neon Blue", pygame.K_e: "Golden"}
                        t_keys = {pygame.K_a: "Classic Navy", pygame.K_s: "Cyberpunk", pygame.K_d: "Grass Court"}
                        if event.key in p_keys: self.handle_shop_purchase("paddle", p_keys[event.key], PADDLES)
                        if event.key in t_keys: self.handle_shop_purchase("theme", t_keys[event.key], THEMES)
                    elif self.game_state == "DIFFICULTY_SELECT":
                        if event.key == pygame.K_1: self.init_match(1, False, custom_ai_speed=5.5)
                        if event.key == pygame.K_2: self.init_match(1, False, custom_ai_speed=8.5)
                        if event.key == pygame.K_3: self.init_match(1, False, custom_ai_speed=15.0) 
                        if event.key == pygame.K_ESCAPE:
                            self.game_state = "MENU"
                    elif self.game_state == "PLAYING":
                        if event.key == pygame.K_ESCAPE:
                            if self.lan:
                                self.lan.close()
                                self.lan = None
                                self.lan_role = None
                            self.game_state = "MENU"
                    elif self.game_state == "GAME_OVER":
                        if event.key == pygame.K_ESCAPE or event.key == pygame.K_m:
                            if self.lan:
                                self.lan.close()
                                self.lan = None
                                self.lan_role = None
                            self.game_state = "MENU"
                        if event.key == pygame.K_RETURN and self.tournament_active:
                            self.init_match(1, True)
                    elif self.game_state == "TOURNAMENT_OVER":
                        if event.key == pygame.K_ESCAPE or event.key == pygame.K_m:
                            if self.lan:
                                self.lan.close()
                                self.lan = None
                                self.lan_role = None
                            self.game_state = "MENU"

            if self.game_state == "MENU":
                self.render_menu()
            elif self.game_state == "SHOP":
                self.render_shop()
            elif self.game_state == "DIFFICULTY_SELECT":
                self.render_difficulty_select()
            else:
                if self.game_state == "PLAYING":
                    if self.lan and self.lan_role == "client":
                        self.send_lan_controls()
                        self.receive_lan_state()
                    else:
                        if self.lan and self.lan_role == "host":
                            self.receive_lan_state()
                        self.process_inputs()
                        self.update_ai()
                        self.update_physics()
                        if self.lan and self.lan_role == "host":
                            self.send_lan_state()
                self.render_game()

            pygame.display.flip()
            self.clock.tick(60)

if __name__ == "__main__":
    game = PyPongGame(player_name="Student_Player", winning_score=11)
    game.run()